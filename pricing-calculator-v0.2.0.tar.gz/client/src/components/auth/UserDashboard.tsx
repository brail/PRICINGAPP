/**
 * Pricing Calculator v0.2 - User Dashboard Component
 * Dashboard utente con informazioni personali
 */

import React, { useState } from "react";
import {
  Box,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  CircularProgress,
} from "@mui/material";
import CustomButton from "../CustomButton";
import {
  useBusinessErrorHandler,
  createBusinessError,
} from "../../hooks/useBusinessErrorHandler";
import { useNotification } from "../../contexts/NotificationContext";
import CompactErrorHandler from "../CompactErrorHandler";
import {
  Person,
  AdminPanelSettings,
  Edit,
  Save,
  Cancel,
  Lock,
} from "@mui/icons-material";
import { useAuth } from "../../contexts/AuthContext";
import { useVersion } from "../../hooks/useVersion";
import ChangePasswordDialog from "./ChangePasswordDialog";
import "./UserDashboard.css";

const UserDashboard: React.FC = () => {
  const { user, updateUser, isLoading } = useAuth();
  const { version, buildDate, environment } = useVersion();
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [changePasswordDialogOpen, setChangePasswordDialogOpen] =
    useState(false);
  const [editForm, setEditForm] = useState({
    username: user?.username || "",
    email: user?.email || "",
  });
  const [saving, setSaving] = useState(false);

  // Business error handler
  const { errors, addError, removeError, clearErrors } =
    useBusinessErrorHandler();

  // Notification system
  const { showSuccess } = useNotification();

  const handleEditProfile = () => {
    setEditForm({
      username: user?.username || "",
      email: user?.email || "",
    });
    setEditDialogOpen(true);
    clearErrors();
  };

  const handleSaveProfile = async () => {
    try {
      setSaving(true);
      clearErrors();
      await updateUser(editForm);
      setEditDialogOpen(false);
    } catch (err: any) {
      addError(
        createBusinessError.system(
          err.message || "Errore nell'aggiornamento del profilo",
          "Errore di aggiornamento profilo"
        )
      );
    } finally {
      setSaving(false);
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case "admin":
        return <AdminPanelSettings />;
      case "user":
        return <Person />;
      default:
        return <Person />;
    }
  };

  const formatDate = (dateString: string | undefined) => {
    if (!dateString) return "Mai";
    return new Date(dateString).toLocaleDateString("it-IT", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (!user) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">Utente non trovato</Alert>
      </Box>
    );
  }

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h2>Dashboard Utente</h2>
        <p className="text-muted">
          Gestisci il tuo profilo e le impostazioni dell'account.
        </p>
      </div>

      <div className="dashboard-content">
        <div className="dashboard-grid">
          {/* Card Profilo */}
          <div className="dashboard-card">
            <div className="profile-header">
              <div className="profile-avatar">{getRoleIcon(user.role)}</div>
              <div className="profile-info">
                <h4>{user.username}</h4>
                <span className={`profile-role ${user.role}`}>
                  {user.role.toUpperCase()}
                </span>
              </div>
            </div>

            <div className="profile-divider"></div>

            <div className="profile-field">
              <span className="profile-field-label">Email</span>
              <span className="profile-field-value">{user.email}</span>
            </div>

            <div className="profile-field">
              <span className="profile-field-label">Membro dal</span>
              <span className="profile-field-value">
                {formatDate(user.created_at)}
              </span>
            </div>

            <div className="profile-field">
              <span className="profile-field-label">Ultimo accesso</span>
              <span className="profile-field-value">
                {formatDate(user.last_login)}
              </span>
            </div>

            <div className="profile-actions">
              <CustomButton
                variant="outline"
                onClick={handleEditProfile}
                disabled={isLoading}
              >
                <Edit className="btn-icon" />
                Modifica Profilo
              </CustomButton>
              <CustomButton
                variant="outline"
                onClick={() => setChangePasswordDialogOpen(true)}
                disabled={isLoading}
              >
                <Lock className="btn-icon" />
                Cambia Password
              </CustomButton>
            </div>
          </div>

          {/* Card Statistiche */}
          <div className="dashboard-card">
            <h3>Statistiche Account</h3>

            <div className="stats-grid">
              <div className="stat-item">
                <span className="stat-label">Ruolo</span>
                <span className={`stat-chip ${user.role}`}>
                  {user.role === "admin"
                    ? "Amministratore"
                    : user.role === "user"
                    ? "Utente"
                    : "Ospite"}
                </span>
              </div>

              <div className="stat-item">
                <span className="stat-label">Permessi</span>
                <span className="stat-value">
                  {user.role === "admin"
                    ? "Accesso completo"
                    : user.role === "user"
                    ? "Accesso standard"
                    : "Accesso limitato"}
                </span>
              </div>

              <div className="stat-item">
                <span className="stat-label">Versione App</span>
                <span className="stat-value">
                  v{version}
                  {environment === "development" && "-dev"}
                  {buildDate &&
                    ` (${new Date(buildDate).toLocaleDateString()})`}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Dialog per modifica profilo */}
      <Dialog
        open={editDialogOpen}
        onClose={() => setEditDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Modifica Profilo</DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2 }}>
            {/* Compact Error Handler */}
            {errors.map((businessError) => (
              <CompactErrorHandler
                key={businessError.id}
                error={businessError}
                onDismiss={() => removeError(businessError.id)}
              />
            ))}

            <TextField
              fullWidth
              label="Username"
              value={editForm.username}
              onChange={(e) =>
                setEditForm((prev) => ({ ...prev, username: e.target.value }))
              }
              sx={{ mb: 2 }}
            />

            <TextField
              fullWidth
              label="Email"
              type="email"
              value={editForm.email}
              onChange={(e) =>
                setEditForm((prev) => ({ ...prev, email: e.target.value }))
              }
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <CustomButton
            onClick={() => setEditDialogOpen(false)}
            disabled={saving}
          >
            <Cancel />
            Annulla
          </CustomButton>
          <CustomButton
            onClick={handleSaveProfile}
            variant="primary"
            disabled={saving}
          >
            {saving ? <CircularProgress size={20} /> : <Save />}
            {saving ? "Salvataggio..." : "Salva"}
          </CustomButton>
        </DialogActions>
      </Dialog>

      {/* Dialog per cambio password */}
      <ChangePasswordDialog
        open={changePasswordDialogOpen}
        onClose={() => setChangePasswordDialogOpen(false)}
        onSuccess={() => {
          // Opzionale: mostra un messaggio di successo
        }}
      />
    </div>
  );
};

export default UserDashboard;
